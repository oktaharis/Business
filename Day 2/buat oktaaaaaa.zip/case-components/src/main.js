// import './assets/main.css'

import { createApp } from 'vue'
import App from './App.vue'

// mount untuk merender
createApp(App).mount('#app')
